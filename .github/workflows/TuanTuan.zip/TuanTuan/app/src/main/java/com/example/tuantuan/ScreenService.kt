package com.example.tuantuan

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** 只读取屏幕上可见的文字。跳过密码框、输入框，以及聊天/支付/银行/密码类应用。 */
class ScreenService : AccessibilityService() {

    data class Screen(val app: String, val text: String)

    companion object {
        @Volatile
        var instance: ScreenService? = null

        private val BLOCK = setOf(
            "com.tencent.mm", "com.tencent.mobileqq", "com.eg.android.AlipayGphone",
            "com.unionpay", "com.android.systemui", "com.android.settings", "com.example.tuantuan"
        )
        private val BLOCK_WORDS = listOf(
            "bank", "pay", "wallet", "password", "authenticator",
            "keepass", "bitwarden", "launcher", ".home"
        )
    }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onDestroy() { instance = null; super.onDestroy() }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun readScreen(): Screen? {
        val root = rootInActiveWindow ?: return null
        val pkg = root.packageName?.toString() ?: return null
        val lower = pkg.lowercase()
        if (pkg in BLOCK || BLOCK_WORDS.any { lower.contains(it) }) return null
        val lines = LinkedHashSet<String>()
        collect(root, lines, 0)
        val text = lines.joinToString("\n").take(700)
        if (text.length < 8) return null
        val label = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }
        return Screen(label, text)
    }

    private fun collect(n: AccessibilityNodeInfo?, out: MutableSet<String>, depth: Int) {
        if (n == null || depth > 30 || out.size >= 60) return
        if (!n.isVisibleToUser || n.isPassword) return
        if (!n.isEditable) {
            val t = (n.text ?: n.contentDescription)?.toString()?.trim()
            if (t != null && t.length in 2..200) out.add(t)
        }
        for (i in 0 until n.childCount) collect(n.getChild(i), out, depth + 1)
    }
}
