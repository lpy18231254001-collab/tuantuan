package com.example.tuantuan

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

/** 一排可单选的圆角小标签。 */
class ChipGroup(
    ctx: Context,
    labels: List<String>,
    initial: Int,
    private val onPick: (Int) -> Unit
) {
    private val d = ctx.resources.displayMetrics.density
    val view = LinearLayout(ctx)
    var selected = initial
        private set
    private val chips = mutableListOf<TextView>()

    init {
        view.orientation = LinearLayout.HORIZONTAL
        view.setPadding(0, (6 * d).toInt(), 0, 0)
        labels.forEachIndexed { i, s ->
            val tv = TextView(ctx).apply {
                text = s
                textSize = 14f
                gravity = Gravity.CENTER
                setPadding(0, (10 * d).toInt(), 0, (10 * d).toInt())
                setOnClickListener { select(i); onPick(i) }
            }
            chips.add(tv)
            view.addView(
                tv,
                LinearLayout.LayoutParams(0, WRAP, 1f).apply {
                    setMargins((3 * d).toInt(), 0, (3 * d).toInt(), 0)
                }
            )
        }
        select(initial)
    }

    fun select(i: Int) {
        selected = i
        chips.forEachIndexed { k, tv ->
            val on = k == i
            tv.setTextColor(if (on) 0xFFFFFFFF.toInt() else 0xFF8A7BA3.toInt())
            tv.background = GradientDrawable().apply {
                cornerRadius = 100 * d
                setColor(if (on) 0xFFFF8FB1.toInt() else 0xFFF6F1FA.toInt())
            }
        }
    }
}
