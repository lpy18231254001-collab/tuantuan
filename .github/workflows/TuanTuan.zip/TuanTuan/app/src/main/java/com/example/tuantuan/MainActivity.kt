package com.example.tuantuan

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var rbOpenAi: RadioButton
    private lateinit var rbClaude: RadioButton
    private lateinit var etBase: EditText
    private lateinit var etModel: EditText
    private lateinit var etKey: EditText
    private lateinit var rgWatch: RadioGroup
    private lateinit var tvScreen: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val pad = (24 * d).toInt()
        val sp = getSharedPreferences("cfg", 0)
        try {

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        fun label(t: String, size: Float = 16f, top: Int = 0) = TextView(this).apply {
            text = t; textSize = size; setPadding(0, top, 0, 0)
        }

        CrashLog.last(this)?.let { log ->
            root.addView(TextView(this).apply {
                text = "上次的出错记录（点下面按钮复制后发给开发者）：\n$log"
                textSize = 11f
                setTextIsSelectable(true)
            })
            root.addView(Button(this).apply {
                text = "复制出错记录"
                setOnClickListener {
                    val cm = this@MainActivity.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("log", log))
                    Toast.makeText(this@MainActivity, "已复制", Toast.LENGTH_SHORT).show()
                }
            })
            root.addView(Button(this).apply {
                text = "清除记录"
                setOnClickListener { CrashLog.clear(this@MainActivity); recreate() }
            })
        }
        root.addView(label("团团", 34f))
        root.addView(label("轻点团团：直接在屏幕上跟它聊天\n按住拖动：带它去别的地方\n长按不动：让它睡觉 / 叫醒", 14f, pad / 2))

        root.addView(label("AI 接口", 16f, pad))
        val rg = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        rbOpenAi = RadioButton(this).apply {
            id = View.generateViewId(); text = "OpenAI 兼容格式（DeepSeek、Kimi、通义等）"
        }
        rbClaude = RadioButton(this).apply {
            id = View.generateViewId(); text = "Claude（Anthropic 官方接口）"
        }
        rg.addView(rbOpenAi)
        rg.addView(rbClaude)
        root.addView(rg)

        etBase = EditText(this).apply {
            hint = "接口地址，如 https://api.deepseek.com"
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setText(sp.getString("base", ""))
        }
        etModel = EditText(this).apply {
            hint = "模型名（按服务商文档填写）"
            setSingleLine()
            setText(sp.getString("model", ""))
        }
        etKey = EditText(this).apply {
            hint = "API Key"
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(sp.getString("key", ""))
        }
        root.addView(etBase)
        root.addView(etModel)
        root.addView(etKey)

        if (sp.getString("type", "openai") == "anthropic") rbClaude.isChecked = true
        else rbOpenAi.isChecked = true
        rg.setOnCheckedChangeListener { _, checked ->
            if (checked == rbClaude.id) {
                if (!etBase.text.toString().contains("anthropic")) {
                    etBase.setText("https://api.anthropic.com")
                    etModel.setText("claude-haiku-5-5")
                }
            } else if (etBase.text.toString().contains("anthropic")) {
                etBase.setText("")
                etModel.setText("")
            }
        }

        root.addView(label("屏幕识别", 16f, pad))
        tvScreen = label("", 14f, pad / 4)
        root.addView(tvScreen)
        root.addView(Button(this).apply {
            text = "去系统设置开启屏幕识别"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        rgWatch = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        val cur = sp.getInt("watch", 2)
        listOf("关闭，不看屏幕" to 0, "偶尔（约 5 分钟一次）" to 5, "正常（约 2 分钟一次）" to 2, "话痨（约 1 分钟一次）" to 1)
            .forEach { (name, mins) ->
                rgWatch.addView(RadioButton(this).apply {
                    id = View.generateViewId(); text = name; tag = mins; isChecked = (mins == cur)
                })
            }
        root.addView(rgWatch)
        root.addView(label(
            "只读屏幕上的文字，看不到纯图片和视频。不读密码框和输入框，微信、QQ、支付宝、银行和密码类应用会自动跳过。" +
                "读到的文字会发给你选的 AI 服务商。\n如果系统提示“受限制的设置”：设置 → 应用 → 团团 → 右上角 ⋮ → 允许受限制的设置，再回来开启。",
            12f, pad / 4
        ))

        root.addView(Button(this).apply {
            text = "保存设置"
            setOnClickListener { save(); Toast.makeText(this@MainActivity, "已保存", Toast.LENGTH_SHORT).show() }
        })
        root.addView(Button(this).apply { text = "召唤团团"; setOnClickListener { summon() } })
        root.addView(Button(this).apply {
            text = "让团团休息"
            setOnClickListener { stopService(Intent(this@MainActivity, PetService::class.java)) }
        })

        setContentView(ScrollView(this).apply { addView(root) })
        } catch (e: Exception) {
            CrashLog.save(this, "主页", e)
            setContentView(TextView(this).apply {
                text = CrashLog.last(this@MainActivity) ?: e.toString()
                textSize = 12f
                setTextIsSelectable(true)
                setPadding(40, 120, 40, 40)
            })
        }
    }

    override fun onResume() {
        super.onResume()
        if (!::tvScreen.isInitialized) return
        tvScreen.text = if (ScreenService.instance != null) "状态：已开启 ✓" else "状态：未开启（需要你在系统设置里手动授权）"
    }

    private fun save() {
        var mins = 2
        for (i in 0 until rgWatch.childCount) {
            val b = rgWatch.getChildAt(i) as RadioButton
            if (b.isChecked) mins = b.tag as Int
        }
        getSharedPreferences("cfg", 0).edit()
            .putString("type", if (rbClaude.isChecked) "anthropic" else "openai")
            .putString("base", etBase.text.toString().trim())
            .putString("model", etModel.text.toString().trim())
            .putString("key", etKey.text.toString().trim())
            .putInt("watch", mins)
            .apply()
    }

    private fun summon() {
        save()
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "请先允许「显示在其他应用上层」，然后返回再点一次", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        startForegroundService(Intent(this, PetService::class.java))
    }
}
