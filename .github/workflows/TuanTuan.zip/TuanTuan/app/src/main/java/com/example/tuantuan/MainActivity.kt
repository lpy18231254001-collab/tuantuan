package com.example.tuantuan

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var rbOpenAi: RadioButton
    private lateinit var rbClaude: RadioButton
    private lateinit var etBase: EditText
    private lateinit var etModel: EditText
    private lateinit var etKey: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val pad = (24 * d).toInt()
        val sp = getSharedPreferences("cfg", 0)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        root.addView(TextView(this).apply { text = "团团"; textSize = 34f })
        root.addView(TextView(this).apply {
            text = "轻点：和团团聊天\n按住拖动：带它去别的地方\n长按不动：让它睡觉 / 叫醒"
            textSize = 14f
            setPadding(0, pad / 2, 0, pad)
        })

        root.addView(TextView(this).apply { text = "AI 接口"; textSize = 16f })
        val rg = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        rbOpenAi = RadioButton(this).apply {
            id = View.generateViewId(); text = "OpenAI 兼容格式（DeepSeek、Kimi、通义等）"
        }
        rbClaude = RadioButton(this).apply {
            id = View.generateViewId(); text = "Claude（Anthropic 官方接口）"
        }
        rg.addView(rbOpenAi)
        rg.addView(rbClaude)
        root.addView(rg)

        etBase = EditText(this).apply {
            hint = "接口地址，如 https://api.deepseek.com"
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setText(sp.getString("base", ""))
        }
        etModel = EditText(this).apply {
            hint = "模型名（按服务商文档填写）"
            setSingleLine()
            setText(sp.getString("model", ""))
        }
        etKey = EditText(this).apply {
            hint = "API Key"
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(sp.getString("key", ""))
        }
        root.addView(etBase)
        root.addView(etModel)
        root.addView(etKey)

        if (sp.getString("type", "openai") == "anthropic") rbClaude.isChecked = true
        else rbOpenAi.isChecked = true

        rg.setOnCheckedChangeListener { _, checked ->
            if (checked == rbClaude.id) {
                if (!etBase.text.toString().contains("anthropic")) {
                    etBase.setText("https://api.anthropic.com")
                    etModel.setText("claude-haiku-5-5")
                }
            } else if (etBase.text.toString().contains("anthropic")) {
                etBase.setText("")
                etModel.setText("")
            }
        }

        root.addView(TextView(this).apply {
            text = "Key 只保存在这台手机上，不会上传到别处。聊天内容会发送给你选择的 AI 服务商，用量由服务商计费。"
            textSize = 12f
            setPadding(0, pad / 3, 0, pad / 2)
        })

        root.addView(Button(this).apply {
            text = "保存设置"
            setOnClickListener { save(); Toast.makeText(this@MainActivity, "已保存", Toast.LENGTH_SHORT).show() }
        })
        root.addView(Button(this).apply {
            text = "召唤团团"
            setOnClickListener { summon() }
        })
        root.addView(Button(this).apply {
            text = "让团团休息"
            setOnClickListener { stopService(Intent(this@MainActivity, PetService::class.java)) }
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun save() {
        getSharedPreferences("cfg", 0).edit()
            .putString("type", if (rbClaude.isChecked) "anthropic" else "openai")
            .putString("base", etBase.text.toString().trim())
            .putString("model", etModel.text.toString().trim())
            .putString("key", etKey.text.toString().trim())
            .apply()
    }

    private fun summon() {
        save()
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "请先允许「显示在其他应用上层」，然后返回再点一次", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        startForegroundService(Intent(this, PetService::class.java))
    }
}
