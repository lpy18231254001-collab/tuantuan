package com.example.tuantuan

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var etBase: EditText
    private lateinit var etModel: EditText
    private lateinit var etKey: EditText
    private lateinit var typeChips: ChipGroup
    private lateinit var watchChips: ChipGroup
    private lateinit var moveChips: ChipGroup
    private lateinit var screenChips: ChipGroup
    private lateinit var voiceChips: ChipGroup
    private lateinit var volChips: ChipGroup
    private lateinit var voice: Voice
    private lateinit var tvScreen: TextView
    private val watchMins = intArrayOf(0, 5, 2, 1)

    private val PINK = 0xFFFF8FB1.toInt()
    private val BLUE = 0xFF8FB8FF.toInt()
    private val MINT = 0xFF6FCFB0.toInt()
    private val PURPLE = 0xFF6B4E8A.toInt()
    private val SOFT = 0xFF9A8CB0.toInt()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = 0xFFFFE6F0.toInt()
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        try {
            build()
        } catch (e: Exception) {
            CrashLog.save(this, "主页", e)
            setContentView(TextView(this).apply {
                text = CrashLog.last(this@MainActivity) ?: e.toString()
                textSize = 12f
                setTextIsSelectable(true)
                setPadding(40, 120, 40, 40)
            })
        }
    }

    private fun build() {
        val sp = getSharedPreferences("cfg", 0)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(28), dp(18), dp(32))
        }

        CrashLog.last(this)?.let { log ->
            root.addView(card(
                "上次的出错记录",
                TextView(this).apply { text = log; textSize = 11f; setTextIsSelectable(true) },
                pill("复制出错记录", BLUE) {
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("log", log))
                    toast("已复制")
                },
                pill("清除记录", PINK) { CrashLog.clear(this); recreate() }
            ))
        }

        root.addView(header())

        root.addView(card(
            "召唤 🐾",
            pill("召唤团团", PINK) { summon() },
            pill("让团团休息", BLUE) { stopService(Intent(this, PetService::class.java)) }
        ))

        watchChips = ChipGroup(
            this, listOf("安静", "偶尔", "正常", "话痨"),
            watchMins.indexOf(sp.getInt("watch", 2)).coerceAtLeast(0)
        ) { save() }
        moveChips = ChipGroup(this, listOf("待在原地", "左右走动"), sp.getInt("move", 0).coerceIn(0, 1)) { save() }
        screenChips = ChipGroup(
            this, listOf("参考屏幕", "不参考"), if (sp.getBoolean("useScreen", true)) 0 else 1
        ) { save() }
        tvScreen = note("")

        root.addView(card(
            "性格和互动 💬",
            label("主动逗我的频率"), watchChips.view,
            note("偶尔≈5分钟 · 正常≈2分钟 · 话痨≈1分钟一次。选“安静”它就不会主动开口。"),
            label("走路方式"), moveChips.view,
            label("说话时看屏幕"), screenChips.view,
            tvScreen,
            pill("去系统设置开启屏幕识别", MINT) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
            note(
                "只读屏幕上的文字，看不到纯图片和视频。不读密码框和输入框，微信、QQ、支付宝、银行和密码类应用会自动跳过。" +
                    "读到的文字会发给你选的 AI 服务商。\n如果系统提示“受限制的设置”：设置 → 应用 → 团团 → 右上角 ⋮ → 允许受限制的设置，再回来开启。"
            )
        ))

        voiceChips = ChipGroup(this, listOf("静音", "叽喳声", "读出来"), sp.getInt("voice", 1).coerceIn(0, 2)) { save() }
        volChips = ChipGroup(this, listOf("小声", "适中", "大声"), sp.getInt("vol", 1).coerceIn(0, 2)) { save() }
        voice = Voice(this)
        root.addView(card(
            "声音 🔊",
            label("团团说话时"), voiceChips.view,
            label("音量"), volChips.view,
            pill("试听一下", MINT) { save(); voice.speak("嗨～我是团团，今天也要开心哦！", true) },
            note(
                "叽喳声：边说边发出软萌的小怪声，不读具体的字。\n读出来：用手机自带的中文语音朗读，音调调高了（手机里要有中文语音引擎）。\n" +
                    "声音走媒体音量，放音乐、视频或通话时团团不会出声。\n" +
                    "游戏里的原声录音有版权，我没法放进来，这是我合成的类似风格的声音。"
            )
        ))

        etBase = input("接口地址，如 https://api.deepseek.com", sp.getString("base", "") ?: "", uri = true)
        etModel = input("模型名（按服务商文档填写）", sp.getString("model", "") ?: "")
        etKey = input("API Key", sp.getString("key", "") ?: "", password = true)
        typeChips = ChipGroup(
            this, listOf("OpenAI 兼容格式", "Claude 官方"),
            if (sp.getString("type", "openai") == "anthropic") 1 else 0
        ) { i ->
            if (i == 1) {
                if (!etBase.text.toString().contains("anthropic")) {
                    etBase.setText("https://api.anthropic.com")
                    etModel.setText("claude-haiku-5-5")
                }
            } else if (etBase.text.toString().contains("anthropic")) {
                etBase.setText("")
                etModel.setText("")
            }
            save()
        }
        root.addView(card(
            "AI 小脑袋 🧠",
            typeChips.view, etBase, etModel, etKey,
            note("OpenAI 兼容适用于 DeepSeek、Kimi、通义等。Key 只保存在这台手机上，聊天内容会发给你选的服务商，按用量计费。"),
            pill("保存", PINK) { save(); toast("已保存") }
        ))

        root.addView(card(
            "怎么玩 ✨",
            note("轻点团团：直接在屏幕上跟它聊天\n按住拖动：带它去别的地方\n长按不动：让它睡觉 / 叫醒\n通知栏里可以让它休息")
        ))

        setContentView(ScrollView(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0xFFFFE6F0.toInt(), 0xFFEAF1FF.toInt())
            )
            isFillViewport = true
            addView(root)
        })
    }

    private fun header(): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val lines = listOf(
            "嗨～我是团团！点我会蹦哦", "今天也要元气满满呀 ✨", "快把我召唤到屏幕上嘛～",
            "别戳啦，会痒的！", "长按我可以让我睡觉哦"
        )
        val speech = TextView(this).apply {
            text = lines[0]
            textSize = 14f
            setTextColor(PURPLE)
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(8), dp(14), dp(8))
            background = GradientDrawable().apply {
                setColor(0xFFFFFFFF.toInt())
                cornerRadius = dp(18).toFloat()
                setStroke(dp(1), 0xFFFFD0E0.toInt())
            }
        }
        val pet = PetView(this).apply {
            onTap = { speech.text = lines.random() }
            onSleep = { s -> speech.text = if (s) "呼…呼…zzz" else "唔…醒了" }
        }
        box.addView(speech)
        box.addView(pet, LinearLayout.LayoutParams(dp(120), dp(138)).apply { topMargin = dp(8) })
        box.addView(TextView(this).apply {
            text = "团团"
            textSize = 30f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(PURPLE)
            gravity = Gravity.CENTER
        })
        box.addView(TextView(this).apply {
            text = "你的屏幕小跟班 ✨"
            textSize = 13f
            setTextColor(SOFT)
            gravity = Gravity.CENTER
        })
        return box
    }

    private fun card(title: String, vararg children: View): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(16))
            background = GradientDrawable().apply {
                setColor(0xF5FFFFFF.toInt())
                cornerRadius = dp(22).toFloat()
                setStroke(dp(1), 0xFFFFDCE8.toInt())
            }
            elevation = dp(2).toFloat()
        }
        c.addView(TextView(this).apply {
            text = title
            textSize = 16f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(PURPLE)
        })
        children.forEach { c.addView(it) }
        c.layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(14) }
        return c
    }

    private fun note(t: String) = TextView(this).apply {
        text = t
        textSize = 12f
        setTextColor(SOFT)
        setPadding(0, dp(6), 0, 0)
    }

    private fun label(t: String) = TextView(this).apply {
        text = t
        textSize = 13f
        setTextColor(0xFF8A7BA3.toInt())
        setPadding(0, dp(12), 0, 0)
    }

    private fun input(hintText: String, value: String, password: Boolean = false, uri: Boolean = false) =
        EditText(this).apply {
            hint = hintText
            setText(value)
            setSingleLine()
            textSize = 14f
            setTextColor(0xFF4A4060.toInt())
            setHintTextColor(0xFFB9AECB.toInt())
            inputType = when {
                password -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                uri -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
                else -> InputType.TYPE_CLASS_TEXT
            }
            setPadding(dp(14), dp(11), dp(14), dp(11))
            background = GradientDrawable().apply {
                setColor(0xFFF6F1FA.toInt())
                cornerRadius = dp(14).toFloat()
            }
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) }
        }

    private fun pill(text: String, color: Int, onClick: () -> Unit) = TextView(this).apply {
        this.text = text
        textSize = 16f
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(0xFFFFFFFF.toInt())
        gravity = Gravity.CENTER
        setPadding(0, dp(12), 0, dp(12))
        background = GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(100).toFloat()
        }
        layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) }
        setOnClickListener { onClick() }
    }

    override fun onResume() {
        super.onResume()
        if (!::tvScreen.isInitialized) return
        tvScreen.text = if (ScreenService.instance != null) "屏幕识别状态：已开启 ✓"
        else "屏幕识别状态：未开启（需要你在系统设置里手动授权）"
    }

    override fun onPause() {
        super.onPause()
        if (::etKey.isInitialized && ::typeChips.isInitialized && ::volChips.isInitialized) save()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::voice.isInitialized) voice.shutdown()
    }

    private fun save() {
        getSharedPreferences("cfg", 0).edit()
            .putString("type", if (typeChips.selected == 1) "anthropic" else "openai")
            .putString("base", etBase.text.toString().trim())
            .putString("model", etModel.text.toString().trim())
            .putString("key", etKey.text.toString().trim())
            .putInt("watch", watchMins[watchChips.selected])
            .putInt("move", moveChips.selected)
            .putBoolean("useScreen", screenChips.selected == 0)
            .putInt("voice", voiceChips.selected)
            .putInt("vol", volChips.selected)
            .apply()
    }

    private fun summon() {
        save()
        if (!Settings.canDrawOverlays(this)) {
            toast("请先允许「显示在其他应用上层」，然后返回再点一次")
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        startForegroundService(Intent(this, PetService::class.java))
    }
}
