package com.example.tuantuan

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class ChatActivity : Activity() {

    private lateinit var log: TextView
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var sendBtn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val pad = (16 * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        log = TextView(this).apply { textSize = 15f }
        scroll = ScrollView(this).apply { addView(log) }
        root.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, (220 * d).toInt()
        ))

        input = EditText(this).apply {
            hint = "跟团团说点什么…"
            maxLines = 3
        }
        root.addView(input)

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        sendBtn = Button(this).apply { text = "发送"; setOnClickListener { send() } }
        val clearBtn = Button(this).apply {
            text = "清空"
            setOnClickListener { AiClient.clear(); log.text = "" }
        }
        val closeBtn = Button(this).apply { text = "关闭"; setOnClickListener { finish() } }
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        row.addView(sendBtn, lp)
        row.addView(clearBtn, LinearLayout.LayoutParams(lp))
        row.addView(closeBtn, LinearLayout.LayoutParams(lp))
        root.addView(row)

        setContentView(root)
        window.setLayout((resources.displayMetrics.widthPixels * 0.92f).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)

        synchronized(AiClient.history) {
            AiClient.history.forEach {
                append((if (it.role == "user") "你：" else "团团：") + it.content)
            }
        }
    }

    private fun append(s: String) {
        log.append(s + "\n\n")
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun send() {
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        input.setText("")
        append("你：$t")
        sendBtn.isEnabled = false
        PetBridge.say?.invoke("想想…")
        val app = applicationContext
        Thread {
            try {
                val r = AiClient.chat(app, t)
                runOnUiThread { append("团团：$r"); sendBtn.isEnabled = true }
                PetBridge.say?.invoke(r)
            } catch (e: Exception) {
                runOnUiThread { append("出错了：${e.message}"); sendBtn.isEnabled = true }
                PetBridge.say?.invoke("呜，连不上…")
            }
        }.start()
    }
}
