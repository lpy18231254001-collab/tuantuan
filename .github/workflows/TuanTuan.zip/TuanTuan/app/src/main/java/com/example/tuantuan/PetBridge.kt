package com.example.tuantuan

/** 聊天窗口 -> 悬浮的团团 之间传话用。 */
object PetBridge {
    @Volatile
    var say: ((String) -> Unit)? = null
}
