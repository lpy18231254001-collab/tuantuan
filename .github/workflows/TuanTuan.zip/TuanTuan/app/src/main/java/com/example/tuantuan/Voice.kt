package com.example.tuantuan

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Bundle
import android.os.SystemClock
import android.speech.tts.TextToSpeech
import java.util.Locale
import kotlin.math.PI
import kotlin.math.sin

/**
 * 团团的声音。
 * 模式 0 静音；1 叽喳声（自己合成的软萌小怪声，每个字一个小音节，不读具体字）；
 * 2 读出来（手机自带的中文语音，音调调高；没有中文语音引擎时自动改用叽喳声）。
 */
class Voice(context: Context) {

    private val ctx = context.applicationContext
    private val sp = ctx.getSharedPreferences("cfg", 0)
    private val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val sr = 22050
    private val lock = Any()

    @Volatile private var seq = 0
    @Volatile private var playingUntil = 0L
    private var track: AudioTrack? = null
    private var tts: TextToSpeech? = null
    @Volatile private var ttsOk = false

    private val shortPause = "，,、；;：:"
    private val longPause = "。.！!？?…~～"

    fun speak(text: String, force: Boolean = false) {
        val mode = sp.getInt("voice", 1)
        if (mode == 0) return
        val now = SystemClock.uptimeMillis()
        if (!force) {
            if (am.mode != AudioManager.MODE_NORMAL) return
            if (now > playingUntil && am.isMusicActive) return
        }
        val vol = floatArrayOf(0.35f, 0.7f, 1f)[sp.getInt("vol", 1).coerceIn(0, 2)]
        stop()
        if (mode == 2) {
            ensureTts()
            val t = tts
            val clean = text.replace(Regex("[^\\p{L}\\p{N}，。！？、；：,.!? ~～…]"), "").trim().take(150)
            if (t != null && ttsOk && clean.isNotEmpty()) {
                val b = Bundle()
                b.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, vol)
                t.speak(clean, TextToSpeech.QUEUE_FLUSH, b, "pet")
                playingUntil = now + 800L + clean.length * 280L
                return
            }
        }
        babble(text.take(60), vol)
    }

    fun stop() {
        seq++
        synchronized(lock) {
            try { track?.stop() } catch (_: Exception) {}
            try { track?.release() } catch (_: Exception) {}
            track = null
        }
        try { tts?.stop() } catch (_: Exception) {}
    }

    fun shutdown() {
        stop()
        try { tts?.shutdown() } catch (_: Exception) {}
        tts = null
    }

    private fun ensureTts() {
        if (tts != null) return
        tts = TextToSpeech(ctx) { status ->
            val t = tts
            if (status == TextToSpeech.SUCCESS && t != null) {
                val r = t.setLanguage(Locale.CHINA)
                ttsOk = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
                t.setPitch(1.9f)
                t.setSpeechRate(1.1f)
                t.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
            }
        }
    }

    private fun babble(text: String, vol: Float) {
        val my = seq
        Thread {
            try {
                val pcm = synth(text, vol)
                if (pcm.isEmpty() || my != seq) return@Thread
                val tr = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sr)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(pcm.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()
                tr.write(pcm, 0, pcm.size)
                val ms = pcm.size * 1000L / sr
                synchronized(lock) {
                    if (my != seq) { tr.release(); return@Thread }
                    track = tr
                }
                playingUntil = SystemClock.uptimeMillis() + ms + 300
                tr.play()
                Thread.sleep(ms + 300)
                synchronized(lock) { if (track === tr) track = null }
                try { tr.release() } catch (_: Exception) {}
            } catch (_: Exception) {
            }
        }.start()
    }

    /** 每个字一个 60 毫秒左右的小音节，音高随字变化，句末的问号会上扬。 */
    private fun synth(text: String, vol: Float): ShortArray {
        val plan = ArrayList<Pair<Char, Int>>()
        var total = 0
        for (ch in text) {
            val n = when {
                shortPause.indexOf(ch) >= 0 -> (0.12 * sr).toInt()
                longPause.indexOf(ch) >= 0 -> (0.22 * sr).toInt()
                ch.isLetterOrDigit() -> (0.062 * sr).toInt()
                else -> 0
            }
            if (n > 0) { plan.add(ch to n); total += n }
        }
        val out = ShortArray(total)
        var pos = 0
        for ((idx, p) in plan.withIndex()) {
            val ch = p.first
            val n = p.second
            if (shortPause.indexOf(ch) >= 0 || longPause.indexOf(ch) >= 0) { pos += n; continue }
            val f0 = 560.0 + (ch.code % 9) * 48.0 + (if (idx % 3 == 0) 40.0 else 0.0)
            val next = plan.getOrNull(idx + 1)?.first
            val glide = when {
                next != null && "？?".indexOf(next) >= 0 -> 0.45
                next != null && "！!".indexOf(next) >= 0 -> 0.25
                else -> 0.18
            }
            var phase = 0.0
            for (i in 0 until n) {
                val t = i.toDouble() / n
                val f = f0 * (1.0 + glide * sin(PI * t)) * (1.0 + 0.012 * sin(2 * PI * 22 * i / sr))
                phase += 2 * PI * f / sr
                val s = sin(phase) + 0.45 * sin(2 * phase) + 0.22 * sin(3 * phase)
                val env = minOf(1.0, i / (0.006 * sr)) * minOf(1.0, (n - i) / (0.014 * sr))
                val v = (s * env * 0.32 * vol * 32767).toInt()
                out[pos + i] = v.coerceIn(-32768, 32767).toShort()
            }
            pos += n
        }
        return out
    }
}
