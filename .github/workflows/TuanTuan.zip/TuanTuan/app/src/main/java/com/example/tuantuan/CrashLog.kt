package com.example.tuantuan

import android.content.Context
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** 把闪退/出错的详细原因存下来，下次打开软件时显示在主页，方便复制。 */
object CrashLog {
    private var lastSoft = 0L

    fun install(ctx: Context) {
        val app = ctx.applicationContext
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { save(app, "崩溃", e) } catch (_: Throwable) {}
            old?.uncaughtException(t, e)
        }
    }

    fun save(ctx: Context, tag: String, e: Throwable) {
        val fatal = tag == "崩溃"
        val now = System.currentTimeMillis()
        if (!fatal) {
            if (now - lastSoft < 5000) return
            lastSoft = now
        }
        val sw = StringWriter()
        e.printStackTrace(PrintWriter(sw))
        val time = SimpleDateFormat("MM-dd HH:mm:ss", Locale.getDefault()).format(Date(now))
        val text = "[$tag $time]\n" + sw.toString().take(2500)
        ctx.applicationContext.getSharedPreferences("crash", 0).edit()
            .putString(if (fatal) "fatal" else "soft", text).commit()
    }

    fun last(ctx: Context): String? {
        val sp = ctx.getSharedPreferences("crash", 0)
        val parts = listOfNotNull(sp.getString("fatal", null), sp.getString("soft", null))
        return if (parts.isEmpty()) null else parts.joinToString("\n\n")
    }

    fun clear(ctx: Context) {
        ctx.getSharedPreferences("crash", 0).edit().clear().commit()
    }
}
