package com.example.tuantuan

import android.content.Context
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.SystemClock
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

private const val OVERLAY = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

/** 团团头顶的说话气泡：逐字出现，点一下消失，不抢焦点。 */
class Bubble(
    private val ctx: Context,
    private val wm: WindowManager,
    private val handler: Handler,
    private val petW: Int,
    private val petH: Int
) {
    private val d = ctx.resources.displayMetrics.density

    private val tv = TextView(ctx).apply {
        layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        textSize = 14f
        setTextColor(0xFF2B2B2B.toInt())
        setPadding((12 * d).toInt(), (8 * d).toInt(), (12 * d).toInt(), (9 * d).toInt())
        maxWidth = (230 * d).toInt()
        background = GradientDrawable().apply {
            setColor(0xF7FFFFFF.toInt())
            cornerRadius = 16 * d
            setStroke(maxOf(1, d.toInt()), 0x22000000)
        }
        setOnClickListener { hide() }
    }

    private val lp = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    private var attached = false
    private var thinkingMode = false
    private var full = ""
    private var shown = 0
    private var ax = 0
    private var ay = 0
    private var dots = 0

    val showing: Boolean get() = attached
    val typing: Boolean get() = attached && !thinkingMode && shown < full.length

    private val hider = Runnable { hide() }

    private val dotter = object : Runnable {
        override fun run() {
            dots = (dots + 1) % 3
            tv.text = "·".repeat(dots + 1)
            handler.postDelayed(this, 380)
        }
    }

    private val typer = object : Runnable {
        override fun run() {
            if (shown < full.length) {
                shown++
                if (shown < full.length && Character.isHighSurrogate(full[shown - 1])) shown++
                tv.text = full.substring(0, shown)
                handler.postDelayed(this, 55)
            } else {
                handler.postDelayed(hider, (2600 + full.length * 130L).coerceAtMost(20000L))
            }
        }
    }

    private fun cancel() {
        handler.removeCallbacks(typer)
        handler.removeCallbacks(hider)
        handler.removeCallbacks(dotter)
    }

    private fun fit(s: String) {
        tv.text = s
        tv.measure(
            View.MeasureSpec.makeMeasureSpec((240 * d).toInt(), View.MeasureSpec.AT_MOST),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        lp.width = tv.measuredWidth
        lp.height = tv.measuredHeight
    }

    private fun place() {
        val dm = ctx.resources.displayMetrics
        lp.x = (ax + petW / 2 - lp.width / 2).coerceIn(0, maxOf(0, dm.widthPixels - lp.width))
        var y = ay + (petH * 0.2f).toInt() - lp.height
        if (y < 0) y = ay + petH - (petH * 0.1f).toInt()
        lp.y = y.coerceIn(0, maxOf(0, dm.heightPixels - lp.height))
    }

    private fun attach() {
        place()
        if (attached) wm.updateViewLayout(tv, lp) else { wm.addView(tv, lp); attached = true }
    }

    fun show(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        cancel()
        thinkingMode = false
        full = t
        fit(t)
        shown = 0
        tv.text = ""
        attach()
        handler.post(typer)
    }

    fun think() {
        cancel()
        thinkingMode = true
        full = ""
        fit("···")
        attach()
        dots = 0
        handler.postDelayed(dotter, 380)
    }

    fun follow(nx: Int, ny: Int) {
        ax = nx
        ay = ny
        if (!attached) return
        val ox = lp.x
        val oy = lp.y
        place()
        if (ox != lp.x || oy != lp.y) wm.updateViewLayout(tv, lp)
    }

    fun hide() {
        cancel()
        thinkingMode = false
        if (attached) {
            try { wm.removeView(tv) } catch (_: Exception) {}
            attached = false
        }
    }
}

/** 悬浮输入条：不用打开软件，直接在屏幕上打字聊天。 */
class ChatBar(
    private val ctx: Context,
    private val wm: WindowManager,
    private val handler: Handler
) {
    var onSend: ((String) -> Unit)? = null
    var onClose: (() -> Unit)? = null
    var isOpen = false
        private set
    var closedAt = 0L
        private set

    private val d = ctx.resources.displayMetrics.density
    private val idle = Runnable { close() }

    private val edit = EditText(ctx).apply {
        hint = "跟团团说点什么…"
        setSingleLine()
        textSize = 15f
        imeOptions = EditorInfo.IME_ACTION_SEND
        setTextColor(0xFF2B2B2B.toInt())
        setHintTextColor(0x88555555.toInt())
        background = null
        setPadding((4 * d).toInt(), (10 * d).toInt(), (4 * d).toInt(), (10 * d).toInt())
    }

    private val sendBtn = TextView(ctx).apply {
        text = "发送"
        textSize = 15f
        gravity = Gravity.CENTER
        setTextColor(0xFFFFFFFF.toInt())
        setPadding((16 * d).toInt(), (8 * d).toInt(), (16 * d).toInt(), (8 * d).toInt())
        background = GradientDrawable().apply { setColor(0xFF3FA37F.toInt()); cornerRadius = 100 * d }
    }

    private val root = object : LinearLayout(ctx) {
        override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
            if (ev.action == MotionEvent.ACTION_OUTSIDE) { close(); return true }
            return super.dispatchTouchEvent(ev)
        }

        override fun dispatchKeyEvent(event: KeyEvent): Boolean {
            if (event.keyCode == KeyEvent.KEYCODE_BACK) {
                if (event.action == KeyEvent.ACTION_UP) close()
                return true
            }
            return super.dispatchKeyEvent(event)
        }
    }.apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding((16 * d).toInt(), (4 * d).toInt(), (8 * d).toInt(), (4 * d).toInt())
        background = GradientDrawable().apply {
            setColor(0xF7FFFFFF.toInt())
            cornerRadius = 100 * d
            setStroke(maxOf(1, d.toInt()), 0x22000000)
        }
        addView(edit, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        addView(sendBtn)
    }

    private val lp = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN or
            WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE
    }

    init {
        sendBtn.setOnClickListener { submit() }
        edit.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_SEND || id == EditorInfo.IME_ACTION_DONE) { submit(); true } else false
        }
        edit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) { bump() }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun imm() = ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager

    private fun submit() {
        val t = edit.text.toString().trim()
        if (t.isEmpty()) return
        edit.setText("")
        bump()
        onSend?.invoke(t)
    }

    fun bump() {
        if (!isOpen) return
        handler.removeCallbacks(idle)
        handler.postDelayed(idle, 30000)
    }

    fun open(topY: Int) {
        if (isOpen) return
        val dm = ctx.resources.displayMetrics
        lp.width = (dm.widthPixels * 0.92f).toInt()
        lp.x = (dm.widthPixels - lp.width) / 2
        lp.y = topY
        edit.setText("")
        wm.addView(root, lp)
        isOpen = true
        handler.postDelayed({
            edit.requestFocus()
            imm().showSoftInput(edit, InputMethodManager.SHOW_IMPLICIT)
        }, 150)
        bump()
    }

    fun close() {
        if (!isOpen) return
        handler.removeCallbacks(idle)
        try { imm().hideSoftInputFromWindow(edit.windowToken, 0) } catch (_: Exception) {}
        try { wm.removeView(root) } catch (_: Exception) {}
        isOpen = false
        closedAt = SystemClock.uptimeMillis()
        onClose?.invoke()
    }
}
