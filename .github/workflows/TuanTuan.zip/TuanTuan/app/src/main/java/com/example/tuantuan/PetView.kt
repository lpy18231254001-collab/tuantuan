package com.example.tuantuan

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.sin

/** 团团本体：灰白色的圆滚滚小猫。画在 130x150 的虚拟画布上，再缩放到窗口大小。 */
class PetView(context: Context) : View(context) {

    var dragging = false
    var sleeping = false
    var facingLeft = false
    var talking = false
    var thinking = false
    var walking = false
    var onDrag: ((Float, Float) -> Unit)? = null
    var onTap: (() -> Unit)? = null
    var onSleep: ((Boolean) -> Unit)? = null
    var onDrop: (() -> Unit)? = null

    private val GREY = 0xFFD6D8DA.toInt()
    private val WHITE = 0xFFFFFFFF.toInt()
    private val INK = 0xFF1B1B1F.toInt()
    private val YELLOW = 0xFFF3F78B.toInt()
    private val TONGUE = 0xFFFF8FA3.toInt()

    private var expr = 0
    private var exprUntil = 0L
    private var hopT = 0f
    private var hopOffset = 0f
    private var breath = 0f
    private var walkPhase = 0f
    private var blinkUntil = 0L
    private var nextBlink = 0L

    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var downTime = 0L
    private val slop = ViewConfiguration.get(context).scaledTouchSlop

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = INK
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val zPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 16f; color = INK }
    private val path = Path()
    private val headPath = Path()
    private val rect = RectF()

    /** 表情：0 普通，1 开心（弯弯眼），2 吐舌头。 */
    fun emote(kind: Int, ms: Long = 2000L) {
        expr = kind
        exprUntil = SystemClock.uptimeMillis() + ms
    }

    fun hop() {
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 480
            addUpdateListener {
                hopT = it.animatedValue as Float
                hopOffset = -18f * sin(PI * hopT).toFloat()
            }
            start()
        }
    }

    private val loop = object : Runnable {
        override fun run() {
            val now = SystemClock.uptimeMillis()
            breath += 0.07f
            if (walking) walkPhase += 0.35f
            if (now > nextBlink) {
                blinkUntil = now + 140
                nextBlink = now + 2200 + (Math.random() * 3000).toLong()
            }
            invalidate()
            postDelayed(this, 33)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        post(loop)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(loop)
        super.onDetachedFromWindow()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX; downY = e.rawY
                lastX = downX; lastY = downY
                downTime = SystemClock.uptimeMillis()
                dragging = false
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging && hypot(e.rawX - downX, e.rawY - downY) > slop * 1.5f) dragging = true
                if (dragging) onDrag?.invoke(e.rawX - lastX, e.rawY - lastY)
                lastX = e.rawX; lastY = e.rawY
            }
            MotionEvent.ACTION_UP -> {
                val wasDrag = dragging
                dragging = false
                val held = SystemClock.uptimeMillis() - downTime
                when {
                    wasDrag -> onDrop?.invoke()
                    held >= 600 -> { sleeping = !sleeping; onSleep?.invoke(sleeping) }
                    sleeping -> { sleeping = false; hop(); onSleep?.invoke(false) }
                    else -> { hop(); onTap?.invoke() }
                }
            }
            MotionEvent.ACTION_CANCEL -> dragging = false
        }
        return true
    }

    private fun drawEye(canvas: Canvas, cx: Float, cy: Float, tilt: Float, outer: Float, closed: Boolean, e: Int) {
        canvas.save()
        line.color = INK
        line.strokeWidth = 4f
        if (closed) {
            path.reset(); path.moveTo(cx - 12f, cy); path.quadTo(cx, cy + 7f, cx + 12f, cy)
            canvas.drawPath(path, line)
        } else if (e == 1) {
            path.reset(); path.moveTo(cx - 12f, cy + 5f); path.quadTo(cx, cy - 11f, cx + 12f, cy + 5f)
            canvas.drawPath(path, line)
        } else {
            canvas.rotate(tilt, cx, cy)
            fill.color = YELLOW
            rect.set(cx - 15f, cy - 11.5f, cx + 15f, cy + 11.5f)
            canvas.drawOval(rect, fill)
            line.strokeWidth = 3.4f
            canvas.drawOval(rect, line)
            val px = cx - outer * 3.5f + 1.5f
            val py = cy + (if (thinking) -3f else 0f)
            fill.color = INK
            rect.set(px - 11.5f, py - 10.5f, px + 11.5f, py + 10.5f)
            canvas.drawOval(rect, fill)
            fill.color = WHITE
            rect.set(px + 1.5f, py - 7f, px + 7f, py - 1.5f)
            canvas.drawOval(rect, fill)
            rect.set(px - 6f, py + 3.5f, px - 3.5f, py + 6f)
            canvas.drawOval(rect, fill)
        }
        canvas.restore()
    }

    override fun onDraw(canvas: Canvas) {
        val now = SystemClock.uptimeMillis()
        val e = if (now < exprUntil) expr else 0
        canvas.save()
        canvas.scale(width / 130f, height / 150f)
        canvas.translate(0f, 20f)

        // 影子
        fill.color = 0x38000000
        rect.set(10f, 118f, 120f, 128f)
        canvas.drawOval(rect, fill)

        val bob = if (walking) -abs(sin(walkPhase)) * 4f else 0f
        val hs = sin(PI * hopT).toFloat()
        val sy = 1f + 0.10f * hs + (if (sleeping) 0.03f else 0.015f) * sin(breath)
        val sx = 1f - 0.05f * hs

        canvas.save()
        canvas.translate(0f, hopOffset + bob)
        if (facingLeft) canvas.scale(-1f, 1f, 65f, 0f)
        canvas.scale(sx, sy, 65f, 124f)
        if (walking) canvas.rotate(sin(walkPhase) * 3f, 65f, 124f)

        // 尾巴（会摇）
        val ang = sin(breath * 0.8f) * (if (e == 1) 14f else 7f)
        canvas.save()
        canvas.rotate(ang, 34f, 108f)
        path.reset(); path.moveTo(36f, 110f); path.quadTo(6f, 116f, 12f, 86f)
        line.color = INK; line.strokeWidth = 17f
        canvas.drawPath(path, line)
        line.color = GREY; line.strokeWidth = 10f
        canvas.drawPath(path, line)
        canvas.restore()
        line.color = INK

        // 小脚
        val l1 = if (walking) maxOf(0f, sin(walkPhase)) * 4f else 0f
        val l2 = if (walking) maxOf(0f, -sin(walkPhase)) * 4f else 0f
        fill.color = WHITE
        line.strokeWidth = 3.6f
        rect.set(36f, 110f - l1, 56f, 126f - l1); canvas.drawOval(rect, fill); canvas.drawOval(rect, line)
        rect.set(74f, 110f - l2, 94f, 126f - l2); canvas.drawOval(rect, fill); canvas.drawOval(rect, line)

        // 身体
        rect.set(30f, 66f, 100f, 120f)
        canvas.drawRoundRect(rect, 26f, 26f, fill)
        canvas.drawRoundRect(rect, 26f, 26f, line)

        // 耳朵
        fill.color = GREY
        path.reset(); path.moveTo(15f, 50f); path.quadTo(3f, 16f, 30f, 20f); path.quadTo(45f, 24f, 48f, 40f); path.close()
        canvas.drawPath(path, fill); canvas.drawPath(path, line)
        path.reset(); path.moveTo(115f, 50f); path.quadTo(127f, 16f, 100f, 20f); path.quadTo(85f, 24f, 82f, 40f); path.close()
        canvas.drawPath(path, fill); canvas.drawPath(path, line)

        // 脑袋：白底 + 灰色头顶
        rect.set(8f, 24f, 122f, 96f)
        fill.color = WHITE
        canvas.drawOval(rect, fill)
        headPath.reset(); headPath.addOval(rect, Path.Direction.CW)
        canvas.save()
        canvas.clipPath(headPath)
        fill.color = GREY
        path.reset(); path.moveTo(0f, 0f); path.lineTo(130f, 0f); path.lineTo(130f, 62f)
        path.quadTo(65f, 74f, 0f, 62f); path.close()
        canvas.drawPath(path, fill)
        canvas.restore()
        line.strokeWidth = 4f
        canvas.drawOval(rect, line)

        // 腮红
        fill.color = if (e == 1) 0x99FF8FA3.toInt() else 0x66FF8FA3.toInt()
        rect.set(24f, 74f, 42f, 85f); canvas.drawOval(rect, fill)
        rect.set(88f, 74f, 106f, 85f); canvas.drawOval(rect, fill)

        // 眼睛
        val closed = sleeping || now < blinkUntil
        drawEye(canvas, 36f, 60f, 10f, -1f, closed, e)
        drawEye(canvas, 94f, 60f, -10f, 1f, closed, e)

        // 嘴
        line.color = INK
        if (!sleeping && e == 2) {
            fill.color = INK
            rect.set(55f, 69f, 75f, 85f); canvas.drawOval(rect, fill)
            fill.color = TONGUE
            rect.set(59f, 77f, 71f, 89f); canvas.drawOval(rect, fill)
        } else if (!sleeping && talking && (now / 170) % 2 == 0L) {
            fill.color = INK
            rect.set(60f, 70f, 70f, 81f); canvas.drawOval(rect, fill)
        } else {
            line.strokeWidth = 3.2f
            path.reset(); path.moveTo(57f, 73f); path.quadTo(61f, 80f, 65f, 74f); path.quadTo(69f, 80f, 73f, 73f)
            canvas.drawPath(path, line)
        }
        canvas.restore()

        if (sleeping) {
            val t = (now % 2400L) / 2400f
            zPaint.alpha = (255 * (1f - t)).toInt()
            canvas.drawText("z", 112f + 10f * t, 22f - 24f * t, zPaint)
            zPaint.alpha = 255
        }
        canvas.restore()
    }
}
