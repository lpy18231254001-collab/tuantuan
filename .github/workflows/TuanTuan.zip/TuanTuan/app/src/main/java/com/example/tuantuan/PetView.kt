package com.example.tuantuan

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import kotlin.math.PI
import kotlin.math.hypot
import kotlin.math.sin

/** 团团：在 150x220 的虚拟画布上画一只圆滚滚的小猫（上方留给对话气泡），再整体缩放到窗口大小。 */
class PetView(context: Context) : View(context) {

    var dragging = false
    var sleeping = false
    var facingLeft = false
    var onDrag: ((Float, Float) -> Unit)? = null
    var onTap: (() -> Unit)? = null

    private val FUR = 0xFFF4C98B.toInt()
    private val FUR2 = 0xFFE7AD62.toInt()
    private val BELLY = 0xFFFFF6E6.toInt()
    private val CHEEK = 0xB3F2A0A0.toInt()
    private val INK = 0xFF2B2B2B.toInt()

    private val chats = listOf("点我可以聊天哦", "你在忙什么呀？", "陪我一会儿嘛", "我在这儿呢", "喝水了吗？")

    private var hopOffset = 0f
    private var breath = 0f
    private var blinkUntil = 0L
    private var nextBlink = 0L
    private var nextChat = 0L
    private var bubbleLines: List<String> = emptyList()
    private var bubbleW = 0f
    private var bubbleUntil = 0L

    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var downTime = 0L
    private val slop = ViewConfiguration.get(context).scaledTouchSlop

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = INK
        strokeCap = Paint.Cap.ROUND
    }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        textSize = 13f
        color = INK
    }
    private val path = Path()
    private val rect = RectF()

    private fun wrap(s: String, maxW: Float): List<String> {
        val out = mutableListOf<String>()
        val sb = StringBuilder()
        for (ch in s) {
            if (ch == '\n') { out.add(sb.toString()); sb.setLength(0); continue }
            if (txt.measureText(sb.toString() + ch) > maxW) { out.add(sb.toString()); sb.setLength(0) }
            sb.append(ch)
        }
        if (sb.isNotEmpty()) out.add(sb.toString())
        return out
    }

    fun say(msg: String, ms: Long = 2400) {
        if (msg.isBlank()) return
        val all = wrap(msg.trim(), 124f)
        val shown = all.take(4).toMutableList()
        if (all.size > 4) shown[3] = shown[3] + "…"
        bubbleLines = shown
        bubbleW = shown.maxOf { txt.measureText(it) }
        bubbleUntil = SystemClock.uptimeMillis() + ms
    }

    private fun hop() {
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 450
            addUpdateListener {
                val t = it.animatedValue as Float
                hopOffset = -34f * sin(PI * t).toFloat()
            }
            start()
        }
    }

    private fun tap() {
        if (sleeping) {
            sleeping = false
            say("唔…醒了")
        } else {
            hop()
            onTap?.invoke()
        }
    }

    private fun toggleSleep() {
        sleeping = !sleeping
        say(if (sleeping) "晚安…" else "唔…醒了", 1600)
    }

    private val loop = object : Runnable {
        override fun run() {
            val now = SystemClock.uptimeMillis()
            breath += 0.07f
            if (now > nextBlink) {
                blinkUntil = now + 140
                nextBlink = now + 2500 + (Math.random() * 3000).toLong()
            }
            if (!sleeping && !dragging && now > nextChat) {
                say(chats.random())
                nextChat = now + 20000 + (Math.random() * 20000).toLong()
            }
            invalidate()
            postDelayed(this, 33)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        nextChat = SystemClock.uptimeMillis() + 25000
        say("你好呀，点我聊天吧", 3000)
        post(loop)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(loop)
        super.onDetachedFromWindow()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX; downY = e.rawY
                lastX = downX; lastY = downY
                downTime = SystemClock.uptimeMillis()
                dragging = false
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging && hypot(e.rawX - downX, e.rawY - downY) > slop * 1.5f) dragging = true
                if (dragging) onDrag?.invoke(e.rawX - lastX, e.rawY - lastY)
                lastX = e.rawX; lastY = e.rawY
            }
            MotionEvent.ACTION_UP -> {
                val wasDrag = dragging
                dragging = false
                val held = SystemClock.uptimeMillis() - downTime
                when {
                    wasDrag -> say("放我下来啦！")
                    held >= 600 -> toggleSleep()
                    else -> tap()
                }
            }
            MotionEvent.ACTION_CANCEL -> dragging = false
        }
        return true
    }

    override fun onDraw(canvas: Canvas) {
        val now = SystemClock.uptimeMillis()
        canvas.save()
        canvas.scale(width / 150f, height / 220f)

        // 对话气泡（底边贴在猫头上方，向上长）
        if (now < bubbleUntil && bubbleLines.isNotEmpty()) {
            val n = bubbleLines.size
            val h = n * 17f + 12f
            val w = bubbleW + 20f
            rect.set(75f - w / 2f, 80f - h, 75f + w / 2f, 80f)
            fill.color = 0xF2FFFFFF.toInt()
            canvas.drawRoundRect(rect, 12f, 12f, fill)
            for ((i, s) in bubbleLines.withIndex()) {
                canvas.drawText(s, 75f, 80f - h + 6f + 17f * (i + 1) - 4f, txt)
            }
        }

        canvas.translate(10f, 85f)

        // 影子
        fill.color = 0x33000000
        rect.set(25f, 116f, 105f, 128f)
        canvas.drawOval(rect, fill)

        canvas.save()
        canvas.translate(0f, hopOffset)
        if (facingLeft) canvas.scale(-1f, 1f, 65f, 0f)
        val b = if (sleeping) 0.03f else 0.02f
        canvas.scale(1f, 1f + b * sin(breath), 65f, 120f)

        // 耳朵
        fill.color = FUR2
        path.reset(); path.moveTo(24f, 56f); path.lineTo(30f, 18f); path.lineTo(56f, 40f); path.close()
        canvas.drawPath(path, fill)
        path.reset(); path.moveTo(106f, 56f); path.lineTo(100f, 18f); path.lineTo(74f, 40f); path.close()
        canvas.drawPath(path, fill)

        // 身体和肚皮
        fill.color = FUR
        rect.set(17f, 40f, 113f, 120f); canvas.drawOval(rect, fill)
        fill.color = BELLY
        rect.set(39f, 76f, 91f, 116f); canvas.drawOval(rect, fill)

        // 眼睛
        val closed = sleeping || now < blinkUntil
        if (closed) {
            line.strokeWidth = 2.4f
            canvas.drawLine(41f, 73f, 51f, 73f, line)
            canvas.drawLine(79f, 73f, 89f, 73f, line)
        } else {
            fill.color = INK
            rect.set(41f, 65f, 51f, 79f); canvas.drawOval(rect, fill)
            rect.set(79f, 65f, 89f, 79f); canvas.drawOval(rect, fill)
        }

        // 腮红
        fill.color = CHEEK
        rect.set(27f, 79.5f, 41f, 88.5f); canvas.drawOval(rect, fill)
        rect.set(89f, 79.5f, 103f, 88.5f); canvas.drawOval(rect, fill)

        // 嘴
        line.strokeWidth = 2.4f
        path.reset(); path.moveTo(58f, 84f); path.quadTo(65f, 91f, 72f, 84f)
        canvas.drawPath(path, line)

        // 胡须
        line.strokeWidth = 1.4f
        line.alpha = 120
        canvas.drawLine(20f, 78f, 6f, 74f, line)
        canvas.drawLine(20f, 84f, 6f, 86f, line)
        canvas.drawLine(110f, 78f, 124f, 74f, line)
        canvas.drawLine(110f, 84f, 124f, 86f, line)
        line.alpha = 255

        canvas.restore()

        // 睡觉的 z
        if (sleeping) {
            val t = (now % 2400L) / 2400f
            txt.alpha = (255 * (1f - t)).toInt()
            canvas.drawText("z", 100f + 14f * t, 20f - 34f * t, txt)
            txt.alpha = 255
        }
        canvas.restore()
    }
}
