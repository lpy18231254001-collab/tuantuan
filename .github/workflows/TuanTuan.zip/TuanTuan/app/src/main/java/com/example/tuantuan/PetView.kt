package com.example.tuantuan

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import kotlin.math.PI
import kotlin.math.hypot
import kotlin.math.sin

/** 团团本体：画在 130x150 的虚拟画布上，再缩放到窗口大小。 */
class PetView(context: Context) : View(context) {

    var dragging = false
    var sleeping = false
    var facingLeft = false
    var talking = false
    var thinking = false
    var onDrag: ((Float, Float) -> Unit)? = null
    var onTap: (() -> Unit)? = null
    var onSleep: ((Boolean) -> Unit)? = null

    private val FUR = 0xFFF4C98B.toInt()
    private val FUR2 = 0xFFE7AD62.toInt()
    private val BELLY = 0xFFFFF6E6.toInt()
    private val CHEEK = 0xB3F2A0A0.toInt()
    private val INK = 0xFF2B2B2B.toInt()

    private var hopOffset = 0f
    private var breath = 0f
    private var blinkUntil = 0L
    private var nextBlink = 0L

    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var downTime = 0L
    private val slop = ViewConfiguration.get(context).scaledTouchSlop

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = INK
        strokeCap = Paint.Cap.ROUND
    }
    private val zPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 16f; color = INK }
    private val path = Path()
    private val rect = RectF()

    fun hop() {
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 450
            addUpdateListener { hopOffset = -16f * sin(PI * (it.animatedValue as Float)).toFloat() }
            start()
        }
    }

    private val loop = object : Runnable {
        override fun run() {
            val now = SystemClock.uptimeMillis()
            breath += 0.07f
            if (now > nextBlink) {
                blinkUntil = now + 140
                nextBlink = now + 2500 + (Math.random() * 3000).toLong()
            }
            invalidate()
            postDelayed(this, 33)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        post(loop)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(loop)
        super.onDetachedFromWindow()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX; downY = e.rawY
                lastX = downX; lastY = downY
                downTime = SystemClock.uptimeMillis()
                dragging = false
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging && hypot(e.rawX - downX, e.rawY - downY) > slop * 1.5f) dragging = true
                if (dragging) onDrag?.invoke(e.rawX - lastX, e.rawY - lastY)
                lastX = e.rawX; lastY = e.rawY
            }
            MotionEvent.ACTION_UP -> {
                val wasDrag = dragging
                dragging = false
                val held = SystemClock.uptimeMillis() - downTime
                when {
                    wasDrag -> {}
                    held >= 600 -> { sleeping = !sleeping; onSleep?.invoke(sleeping) }
                    sleeping -> { sleeping = false; hop(); onSleep?.invoke(false) }
                    else -> { hop(); onTap?.invoke() }
                }
            }
            MotionEvent.ACTION_CANCEL -> dragging = false
        }
        return true
    }

    override fun onDraw(canvas: Canvas) {
        val now = SystemClock.uptimeMillis()
        canvas.save()
        canvas.scale(width / 130f, height / 150f)
        canvas.translate(0f, 20f)

        // 影子
        fill.color = 0x33000000
        rect.set(25f, 116f, 105f, 128f)
        canvas.drawOval(rect, fill)

        canvas.save()
        canvas.translate(0f, hopOffset)
        if (facingLeft) canvas.scale(-1f, 1f, 65f, 0f)
        canvas.scale(1f, 1f + (if (sleeping) 0.03f else 0.02f) * sin(breath), 65f, 120f)

        // 耳朵
        fill.color = FUR2
        path.reset(); path.moveTo(24f, 56f); path.lineTo(30f, 18f); path.lineTo(56f, 40f); path.close()
        canvas.drawPath(path, fill)
        path.reset(); path.moveTo(106f, 56f); path.lineTo(100f, 18f); path.lineTo(74f, 40f); path.close()
        canvas.drawPath(path, fill)

        // 身体和肚皮
        fill.color = FUR
        rect.set(17f, 40f, 113f, 120f); canvas.drawOval(rect, fill)
        fill.color = BELLY
        rect.set(39f, 76f, 91f, 116f); canvas.drawOval(rect, fill)

        // 眼睛（思考时往上看）
        if (sleeping || now < blinkUntil) {
            line.strokeWidth = 2.4f
            canvas.drawLine(41f, 73f, 51f, 73f, line)
            canvas.drawLine(79f, 73f, 89f, 73f, line)
        } else {
            val ey = if (thinking) -4f else 0f
            fill.color = INK
            rect.set(41f, 65f + ey, 51f, 79f + ey); canvas.drawOval(rect, fill)
            rect.set(79f, 65f + ey, 89f, 79f + ey); canvas.drawOval(rect, fill)
        }

        // 腮红
        fill.color = CHEEK
        rect.set(27f, 79.5f, 41f, 88.5f); canvas.drawOval(rect, fill)
        rect.set(89f, 79.5f, 103f, 88.5f); canvas.drawOval(rect, fill)

        // 嘴（说话时一张一合）
        if (!sleeping && talking && (now / 170) % 2 == 0L) {
            fill.color = INK
            rect.set(60f, 82f, 70f, 91f); canvas.drawOval(rect, fill)
        } else {
            line.strokeWidth = 2.4f
            path.reset(); path.moveTo(58f, 84f); path.quadTo(65f, 91f, 72f, 84f)
            canvas.drawPath(path, line)
        }

        // 胡须
        line.strokeWidth = 1.4f
        line.alpha = 120
        canvas.drawLine(20f, 78f, 6f, 74f, line)
        canvas.drawLine(20f, 84f, 6f, 86f, line)
        canvas.drawLine(110f, 78f, 124f, 74f, line)
        canvas.drawLine(110f, 84f, 124f, 86f, line)
        line.alpha = 255

        canvas.restore()

        if (sleeping) {
            val t = (now % 2400L) / 2400f
            zPaint.alpha = (255 * (1f - t)).toInt()
            canvas.drawText("z", 100f + 14f * t, 24f - 26f * t, zPaint)
            zPaint.alpha = 255
        }
        canvas.restore()
    }
}
