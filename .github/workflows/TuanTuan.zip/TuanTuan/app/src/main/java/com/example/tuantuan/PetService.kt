package com.example.tuantuan

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.view.Gravity
import android.view.WindowManager
import kotlin.math.abs

class PetService : Service() {

    companion object {
        const val ACTION_STOP = "com.example.tuantuan.STOP"
        const val CHANNEL = "pet"
    }

    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var bubble: Bubble
    private lateinit var bar: ChatBar
    private var pet: PetView? = null
    private val handler = Handler(Looper.getMainLooper())
    private val sp by lazy { getSharedPreferences("cfg", 0) }

    private var d = 1f
    private var petW = 0
    private var petH = 0
    private var x = 0f
    private var y = 0f
    private var tx = 0f
    private var ty = 0f
    private var homeX = 0f
    private var homeY = 0f
    private var moving = false
    private var pauseUntil = 0L
    private var chatMode = false
    private var returning = false
    private var chatBusy = false

    @Volatile private var busy = false
    @Volatile private var nextAuto = 0L
    @Volatile private var lastSig = 0

    private val hello = listOf("嗨～我来啦！", "团团上线！", "我回来啦，想我没？")
    private val openLines = listOf("嗯？", "在呢", "怎么啦？", "说吧，我听着", "本猫洗耳恭听")
    private val dropLines = listOf("哇啊！放我下来～", "晕了晕了…", "再晃我要吐了啦", "起飞啦！")
    private val sleepLines = listOf("晚安…", "呼…呼…", "我先眯一会儿")
    private val wakeLines = listOf("唔…醒了", "谁戳我？", "我没睡着！我在闭目养神")
    private val bits = listOf(
        "喂，你盯着屏幕多久啦，眼睛要罢工了～",
        "我刚刚打了个哈欠，你看到了吗",
        "偷偷告诉你，我今天一条小鱼干都没偷到",
        "摸鱼是门艺术，我是专业的",
        "嘿，要不要陪我玩一会儿？",
        "我在这儿站岗呢，一切正常（才怪）",
        "你再不理我，我就要在屏幕上蹦迪了",
        "喝口水吧，我监督你！",
        "我宣布：现在是休息时间！",
        "我的尾巴自己动的，不关我的事",
        "猜猜我在想什么？提示：和小鱼干有关"
    )

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            showNotification()
            if (pet == null) addPet()
        } catch (e: Exception) {
            CrashLog.save(this, "启动悬浮窗", e)
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    private fun showNotification() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "团团", NotificationManager.IMPORTANCE_MIN)
        )
        val stopPi = PendingIntent.getService(
            this, 0,
            Intent(this, PetService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentTitle("团团在屏幕上")
            .setContentText("点右边的按钮可以让它休息")
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "让团团休息", stopPi)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun maxX() = (resources.displayMetrics.widthPixels - petW).coerceAtLeast(0).toFloat()
    private fun maxY() = (resources.displayMetrics.heightPixels - petH).coerceAtLeast(0).toFloat()

    private fun addPet() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        d = resources.displayMetrics.density
        petW = (78 * d).toInt()
        petH = (petW * 150f / 130f).toInt()
        lp = WindowManager.LayoutParams(
            petW, petH,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }

        x = maxX() * 0.75f
        y = maxY() * 0.6f
        tx = x
        ty = y
        lp.x = x.toInt()
        lp.y = y.toInt()

        bubble = Bubble(this, wm, handler, petW, petH)
        bar = ChatBar(this, wm, handler)
        bar.onSend = { sendChat(it) }
        bar.onClose = {
            chatMode = false
            returning = true
            tx = homeX
            ty = homeY
        }

        val view = PetView(this)
        view.onDrag = { dx, dy ->
            x = (x + dx).coerceIn(0f, maxX())
            y = (y + dy).coerceIn(0f, maxY())
            tx = x
            ty = y
            moving = false
            moveTo(view)
        }
        view.onDrop = {
            pet?.emote(2, 1500)
            say(dropLines.random())
        }
        view.onTap = { openChat() }
        view.onSleep = { s -> say((if (s) sleepLines else wakeLines).random()) }
        wm.addView(view, lp)
        pet = view

        nextAuto = SystemClock.uptimeMillis() + 30000
        handler.post(tick)
        handler.postDelayed(watch, 8000)
        handler.postDelayed({
            pet?.emote(1, 2000)
            say(hello.random())
        }, 600)
    }

    private fun moveTo(v: PetView) {
        val nx = x.toInt()
        val ny = y.toInt()
        if (nx != lp.x || ny != lp.y) {
            lp.x = nx
            lp.y = ny
            wm.updateViewLayout(v, lp)
        }
    }

    private fun say(t: String) {
        try { bubble.show(t) } catch (e: Exception) { CrashLog.save(this, "气泡", e) }
    }

    private fun openChat() {
        try { openChat2() } catch (e: Exception) { CrashLog.save(this, "打开输入条", e) }
    }

    private fun openChat2() {
        if (bar.isOpen) { bar.close(); return }
        if (SystemClock.uptimeMillis() - bar.closedAt < 700) return
        val dm = resources.displayMetrics
        val barY = (dm.heightPixels * 0.30f).toInt()
        homeX = x
        homeY = y
        moving = false
        bar.open(barY)
        chatMode = true
        returning = false
        tx = (dm.widthPixels - petW) / 2f
        ty = (barY - petH - 6 * d).coerceAtLeast(0f)
        pet?.emote(1, 1500)
        say(openLines.random())
    }

    private fun sendChat(t: String) {
        if (chatBusy) return
        chatBusy = true
        pet?.thinking = true
        bubble.think()
        Thread {
            try {
                val r = AiClient.chat(applicationContext, t)
                handler.post {
                    if (Math.random() < 0.4) pet?.emote(1, 1800)
                    say(r)
                }
            } catch (e: Exception) {
                val m = (e.message ?: "未知错误").take(80)
                handler.post { say("唔…出错了：$m") }
            } finally {
                handler.post {
                    chatBusy = false
                    pet?.thinking = false
                    bar.bump()
                }
            }
        }.start()
    }

    private val tick = object : Runnable {
        override fun run() {
            try { step() } catch (e: Exception) { CrashLog.save(this@PetService, "动画", e) }
            if (pet != null) handler.postDelayed(this, 16)
        }
    }

    private fun step() {
        val p = pet ?: return
        val now = SystemClock.uptimeMillis()
        if (!p.dragging && !p.sleeping) {
            if (chatMode || returning) {
                val dx = tx - x
                val dy = ty - y
                if (dx < -6f) p.facingLeft = true else if (dx > 6f) p.facingLeft = false
                x += dx * 0.08f
                y += dy * 0.08f
                p.walking = abs(dx) > 4f || abs(dy) > 4f
                if (returning && abs(dx) < 2f && abs(dy) < 2f) {
                    returning = false
                    p.walking = false
                }
            } else if (sp.getInt("move", 0) == 1) {
                patrol(p, now)
            } else {
                p.walking = false
            }
            x = x.coerceIn(0f, maxX())
            y = y.coerceIn(0f, maxY())
            moveTo(p)
        } else {
            p.walking = false
        }
        p.talking = bubble.typing
        bubble.follow(lp.x, lp.y)
    }

    /** 只在当前高度左右走：走一段，停一会儿，再走。 */
    private fun patrol(p: PetView, now: Long) {
        if (now < pauseUntil) { p.walking = false; return }
        if (!moving) {
            var t = (Math.random() * maxX()).toFloat()
            if (abs(t - x) < 60 * d) t = if (x > maxX() / 2) maxX() * 0.1f else maxX() * 0.9f
            tx = t
            moving = true
        }
        val dx = tx - x
        if (abs(dx) < 2f) {
            moving = false
            p.walking = false
            pauseUntil = now + 2500 + (Math.random() * 5000).toLong()
            return
        }
        val stepPx = 0.5f * d
        x += if (dx > 0) minOf(stepPx, dx) else maxOf(-stepPx, dx)
        p.facingLeft = dx < 0
        p.walking = true
    }

    /** 隔一会儿主动逗你一下：看屏幕吐槽、讲冷笑话、撒娇、提醒休息…… */
    private val watch = object : Runnable {
        override fun run() {
            handler.postDelayed(this, 8000)
            val mins = sp.getInt("watch", 2)
            if (mins <= 0 || busy || chatBusy || chatMode || returning || bubble.showing) return
            val p = pet ?: return
            if (p.sleeping || p.dragging) return
            if (SystemClock.uptimeMillis() < nextAuto) return
            if (!(getSystemService(POWER_SERVICE) as PowerManager).isInteractive) return
            busy = true
            val useScreen = sp.getBoolean("useScreen", true)
            Thread {
                try {
                    val ctx = applicationContext
                    val s = if (useScreen) ScreenService.instance?.readScreen() else null
                    nextAuto = SystemClock.uptimeMillis() + mins * 60_000L + (Math.random() * mins * 20_000).toLong()
                    var line: String? = null
                    try {
                        val sig = s?.text?.hashCode() ?: 0
                        line = if (s != null && sig != lastSig && Math.random() < 0.7) {
                            lastSig = sig
                            AiClient.comment(ctx, s.app, s.text)
                        } else {
                            AiClient.tease(ctx)
                        }
                    } catch (e: Exception) {
                        line = bits.random()
                    }
                    val out = line
                    if (out != null) handler.post {
                        if (!chatBusy && !chatMode) {
                            pet?.hop()
                            pet?.emote(listOf(0, 1, 1, 2).random(), 2200)
                            say(out)
                        }
                    }
                } catch (e: Exception) {
                    nextAuto = SystemClock.uptimeMillis() + 5 * 60_000L
                } finally {
                    busy = false
                }
            }.start()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if (::bar.isInitialized) bar.close()
        if (::bubble.isInitialized) bubble.hide()
        pet?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        pet = null
        super.onDestroy()
    }
}
