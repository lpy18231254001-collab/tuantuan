package com.example.tuantuan

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.view.Gravity
import android.view.WindowManager

class PetService : Service() {

    companion object {
        const val ACTION_STOP = "com.example.tuantuan.STOP"
        const val CHANNEL = "pet"
    }

    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var bubble: Bubble
    private lateinit var bar: ChatBar
    private var pet: PetView? = null
    private val handler = Handler(Looper.getMainLooper())
    private val sp by lazy { getSharedPreferences("cfg", 0) }

    private var d = 1f
    private var petW = 0
    private var petH = 0
    private var x = 0f
    private var y = 0f
    private var tx = 0f
    private var ty = 0f
    private var nextWander = 0L
    private var chatMode = false
    private var chatBusy = false

    @Volatile private var busy = false
    @Volatile private var nextAuto = 0L
    @Volatile private var lastSig = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        showNotification()
        if (pet == null) addPet()
        return START_STICKY
    }

    private fun showNotification() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "团团", NotificationManager.IMPORTANCE_MIN)
        )
        val stopPi = PendingIntent.getService(
            this, 0,
            Intent(this, PetService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentTitle("团团在屏幕上")
            .setContentText("点右边的按钮可以让它休息")
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "让团团休息", stopPi)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun maxX() = (resources.displayMetrics.widthPixels - petW).coerceAtLeast(0).toFloat()
    private fun maxY() = (resources.displayMetrics.heightPixels - petH).coerceAtLeast(0).toFloat()

    private fun addPet() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        d = resources.displayMetrics.density
        petW = (72 * d).toInt()
        petH = (83 * d).toInt()
        lp = WindowManager.LayoutParams(
            petW, petH,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }

        x = maxX() * 0.75f
        y = maxY() * 0.6f
        tx = x
        ty = y
        lp.x = x.toInt()
        lp.y = y.toInt()

        bubble = Bubble(this, wm, handler, petW, petH)
        bar = ChatBar(this, wm, handler)
        bar.onSend = { sendChat(it) }
        bar.onClose = {
            chatMode = false
            nextWander = SystemClock.uptimeMillis() + 3000
        }

        val view = PetView(this)
        view.onDrag = { dx, dy ->
            x = (x + dx).coerceIn(0f, maxX())
            y = (y + dy).coerceIn(0f, maxY())
            tx = x
            ty = y
            moveTo(view)
        }
        view.onTap = { openChat() }
        view.onSleep = { s -> say(if (s) "晚安…" else "唔…醒了") }
        wm.addView(view, lp)
        pet = view

        nextWander = SystemClock.uptimeMillis() + 3000
        nextAuto = SystemClock.uptimeMillis() + 30000
        handler.post(tick)
        handler.postDelayed(watch, 8000)
        handler.postDelayed({ say("嗨，我来啦") }, 600)
    }

    private fun moveTo(v: PetView) {
        val nx = x.toInt()
        val ny = y.toInt()
        if (nx != lp.x || ny != lp.y) {
            lp.x = nx
            lp.y = ny
            wm.updateViewLayout(v, lp)
        }
    }

    private fun say(t: String) = bubble.show(t)

    private fun openChat() {
        if (bar.isOpen) { bar.close(); return }
        if (SystemClock.uptimeMillis() - bar.closedAt < 700) return
        val dm = resources.displayMetrics
        val barY = (dm.heightPixels * 0.30f).toInt()
        bar.open(barY)
        chatMode = true
        tx = (dm.widthPixels - petW) / 2f
        ty = (barY - petH - 6 * d).coerceAtLeast(0f)
        say(listOf("嗯？", "在呢", "怎么啦？", "说吧，我听着").random())
    }

    private fun sendChat(t: String) {
        if (chatBusy) return
        chatBusy = true
        pet?.thinking = true
        bubble.think()
        Thread {
            try {
                val r = AiClient.chat(applicationContext, t)
                handler.post { say(r) }
            } catch (e: Exception) {
                val m = (e.message ?: "未知错误").take(80)
                handler.post { say("唔…出错了：$m") }
            } finally {
                handler.post {
                    chatBusy = false
                    pet?.thinking = false
                    bar.bump()
                }
            }
        }.start()
    }

    private val tick = object : Runnable {
        override fun run() {
            val p = pet ?: return
            val now = SystemClock.uptimeMillis()
            if (!p.dragging && !p.sleeping) {
                if (!chatMode && now > nextWander) {
                    tx = (Math.random() * maxX()).toFloat()
                    ty = (maxY() * (0.2 + Math.random() * 0.8)).toFloat()
                    nextWander = now + 4000 + (Math.random() * 6000).toLong()
                }
                val dx = tx - x
                if (dx < -6f) p.facingLeft = true else if (dx > 6f) p.facingLeft = false
                val k = if (chatMode) 0.08f else 0.03f
                x += dx * k
                y += (ty - y) * k
                x = x.coerceIn(0f, maxX())
                y = y.coerceIn(0f, maxY())
                moveTo(p)
            }
            p.talking = bubble.typing
            bubble.follow(lp.x, lp.y)
            handler.postDelayed(this, 16)
        }
    }

    /** 隔一会儿看一眼屏幕，有话想说才开口。 */
    private val watch = object : Runnable {
        override fun run() {
            handler.postDelayed(this, 8000)
            val mins = sp.getInt("watch", 2)
            if (mins <= 0 || busy || chatBusy || chatMode || bubble.showing) return
            val p = pet ?: return
            if (p.sleeping || p.dragging) return
            if (SystemClock.uptimeMillis() < nextAuto) return
            if (!(getSystemService(POWER_SERVICE) as PowerManager).isInteractive) return
            val reader = ScreenService.instance ?: return
            busy = true
            Thread {
                try {
                    val s = reader.readScreen() ?: return@Thread
                    val sig = s.text.hashCode()
                    if (sig == lastSig) return@Thread
                    lastSig = sig
                    nextAuto = SystemClock.uptimeMillis() + mins * 60_000L + (Math.random() * mins * 20_000).toLong()
                    val r = AiClient.comment(applicationContext, s.app, s.text)
                    if (r != null) handler.post {
                        if (!chatBusy && !chatMode) {
                            pet?.hop()
                            say(r)
                        }
                    }
                } catch (e: Exception) {
                    nextAuto = SystemClock.uptimeMillis() + 10 * 60_000L
                } finally {
                    busy = false
                }
            }.start()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if (::bar.isInitialized) bar.close()
        if (::bubble.isInitialized) bubble.hide()
        pet?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        pet = null
        super.onDestroy()
    }
}
