package com.example.tuantuan

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.WindowManager

class PetService : Service() {

    companion object {
        const val ACTION_STOP = "com.example.tuantuan.STOP"
        const val CHANNEL = "pet"
    }

    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var pet: PetView? = null
    private val handler = Handler(Looper.getMainLooper())

    private var x = 0f
    private var y = 0f
    private var tx = 0f
    private var ty = 0f
    private var nextWander = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        showNotification()
        if (pet == null) addPet()
        return START_STICKY
    }

    private fun showNotification() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "团团", NotificationManager.IMPORTANCE_MIN)
        )
        val stopPi = PendingIntent.getService(
            this, 0,
            Intent(this, PetService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentTitle("团团在屏幕上")
            .setContentText("点右边的按钮可以让它休息")
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "让团团休息", stopPi)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun maxX() = (resources.displayMetrics.widthPixels - lp.width).coerceAtLeast(0).toFloat()
    private fun maxY() = (resources.displayMetrics.heightPixels - lp.height).coerceAtLeast(0).toFloat()

    private fun addPet() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val d = resources.displayMetrics.density
        lp = WindowManager.LayoutParams(
            (150 * d).toInt(), (220 * d).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }

        x = maxX() / 2f
        y = maxY() * 0.6f
        tx = x
        ty = y
        lp.x = x.toInt()
        lp.y = y.toInt()

        val view = PetView(this)
        view.onDrag = { dx, dy ->
            x = (x + dx).coerceIn(0f, maxX())
            y = (y + dy).coerceIn(0f, maxY())
            tx = x
            ty = y
            apply(view)
        }
        view.onTap = {
            startActivity(
                Intent(this, ChatActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
        PetBridge.say = { msg ->
            handler.post { pet?.say(msg, 3000L + msg.length * 200L) }
        }
        wm.addView(view, lp)
        pet = view
        nextWander = SystemClock.uptimeMillis() + 3000
        handler.post(tick)
    }

    private fun apply(v: PetView) {
        val nx = x.toInt()
        val ny = y.toInt()
        if (nx != lp.x || ny != lp.y) {
            lp.x = nx
            lp.y = ny
            wm.updateViewLayout(v, lp)
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            val p = pet ?: return
            val now = SystemClock.uptimeMillis()
            if (!p.dragging && !p.sleeping) {
                if (now > nextWander) {
                    tx = (Math.random() * maxX()).toFloat()
                    ty = (maxY() * (0.25 + Math.random() * 0.75)).toFloat()
                    nextWander = now + 4000 + (Math.random() * 6000).toLong()
                }
                val dx = tx - x
                if (dx < -6f) p.facingLeft = true else if (dx > 6f) p.facingLeft = false
                x += dx * 0.03f
                y += (ty - y) * 0.03f
                x = x.coerceIn(0f, maxX())
                y = y.coerceIn(0f, maxY())
                apply(p)
            }
            handler.postDelayed(this, 16)
        }
    }

    override fun onDestroy() {
        PetBridge.say = null
        handler.removeCallbacksAndMessages(null)
        pet?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        pet = null
        super.onDestroy()
    }
}
