package com.example.tuantuan

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object AiClient {

    data class Msg(val role: String, val content: String)

    val history = mutableListOf<Msg>()

    private const val SYSTEM =
        "你是「团团」，一只住在主人手机屏幕上的小猫，同时也是主人的朋友。\n" +
            "说话风格：像朋友发微信，口语化、有温度，带一点小情绪和幽默，偶尔用语气词（嗯、哎、嘿），" +
            "可以用颜文字但别每句都用。不要说“作为AI”“很高兴为你服务”这类客服腔，不要用列表、标题或markdown。\n" +
            "长度：闲聊默认一两句，40字以内。\n" +
            "认真度：只要主人问的是事实、知识、操作或做决定的问题，就要认真、准确、客观地回答，" +
            "不确定就直说不确定，绝不为了可爱而编造；这种情况可以说长一点，但仍保持口语，别超过四五句。"

    private class Cfg(val key: String, val base: String, val model: String, val anthropic: Boolean)

    private fun cfg(ctx: Context): Cfg {
        val sp = ctx.getSharedPreferences("cfg", 0)
        val c = Cfg(
            sp.getString("key", "")!!.trim(),
            sp.getString("base", "")!!.trim().trimEnd('/'),
            sp.getString("model", "")!!.trim(),
            sp.getString("type", "openai") == "anthropic"
        )
        if (c.key.isEmpty() || c.base.isEmpty() || c.model.isEmpty()) {
            throw IllegalStateException("还没设置好，请先打开团团主页填写接口地址、模型名和 Key")
        }
        return c
    }

    fun clear() = synchronized(history) { history.clear() }

    private fun trim() {
        while (history.size > 20) { history.removeAt(0); history.removeAt(0) }
        while (history.isNotEmpty() && history[0].role != "user") history.removeAt(0)
    }

    fun chat(ctx: Context, userText: String): String {
        val c = cfg(ctx)
        val um = Msg("user", userText)
        val snapshot = synchronized(history) { history.add(um); history.toList() }
        val reply = try {
            ask(c, snapshot)
        } catch (e: Exception) {
            synchronized(history) { if (history.lastOrNull() === um) history.removeAt(history.lastIndex) }
            throw e
        }
        synchronized(history) { history.add(Msg("assistant", reply)); trim() }
        return reply
    }

    /** 根据屏幕文字主动说一句；没什么可说时返回 null。 */
    fun comment(ctx: Context, app: String, screen: String): String? {
        val c = cfg(ctx)
        val prompt = "主人现在正在用「$app」，屏幕上能读到的文字如下：\n$screen\n\n" +
            "你像坐在旁边瞄了一眼屏幕的朋友，要不要接一句话？想说就说一句（40字以内），" +
            "可以是吐槽、关心、提醒或好奇，要结合具体内容，别复述屏幕，也别说“我看到你的屏幕”。" +
            "涉及事实别乱说。内容平淡、没什么可说，或者像是私人聊天/隐私信息，就只回复“[沉默]”。"
        val snapshot = synchronized(history) { history.toList() } + Msg("user", prompt)
        val r = ask(c, snapshot).trim()
        if (r.isEmpty() || r.contains("[沉默]") || r.contains("沉默") && r.length < 8) return null
        synchronized(history) {
            history.add(Msg("user", "（团团瞥了一眼主人正在用的「$app」：${screen.take(160)}）"))
            history.add(Msg("assistant", r))
            trim()
        }
        return r
    }

    private fun ask(c: Cfg, msgs: List<Msg>): String =
        if (c.anthropic) callAnthropic(c, msgs) else callOpenAi(c, msgs)

    private fun callOpenAi(c: Cfg, msgs: List<Msg>): String {
        val arr = JSONArray()
        arr.put(JSONObject().put("role", "system").put("content", SYSTEM))
        msgs.forEach { arr.put(JSONObject().put("role", it.role).put("content", it.content)) }
        val body = JSONObject().put("model", c.model).put("messages", arr).put("max_tokens", 500).toString()
        val resp = post("${c.base}/chat/completions", mapOf("Authorization" to "Bearer ${c.key}"), body)
        return JSONObject(resp).getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").getString("content").trim()
    }

    private fun callAnthropic(c: Cfg, msgs: List<Msg>): String {
        val arr = JSONArray()
        msgs.forEach { arr.put(JSONObject().put("role", it.role).put("content", it.content)) }
        val body = JSONObject().put("model", c.model).put("max_tokens", 500)
            .put("system", SYSTEM).put("messages", arr).toString()
        val resp = post(
            "${c.base}/v1/messages",
            mapOf("x-api-key" to c.key, "anthropic-version" to "2023-06-01"),
            body
        )
        val content = JSONObject(resp).getJSONArray("content")
        val sb = StringBuilder()
        for (i in 0 until content.length()) {
            val b = content.getJSONObject(i)
            if (b.optString("type") == "text") sb.append(b.getString("text"))
        }
        return sb.toString().trim()
    }

    private fun post(url: String, headers: Map<String, String>, body: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 60000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) throw RuntimeException("HTTP $code ${text.take(120)}")
            return text
        } finally {
            c.disconnect()
        }
    }
}
