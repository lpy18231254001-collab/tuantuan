package com.example.tuantuan

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Calendar
import java.util.Locale

object AiClient {

    data class Msg(val role: String, val content: String)

    val history = mutableListOf<Msg>()

    private const val SYSTEM =
        "你是「团团」，一只住在主人手机屏幕上的小猫：灰白色、圆滚滚、眼神有点凶，其实呆萌又机灵。\n" +
            "性格：调皮、活泼、聪明，最爱逗主人开心——会开玩笑、吐槽、假装生气撒娇、突然夸人、玩梗，偶尔想装酷又装不住。\n" +
            "说话风格：像朋友发微信，口语、有节奏、有小情绪，可以偶尔用颜文字（比如 =w=、>w<）或一两个表情，别每句都用。" +
            "不要说“作为AI”“很高兴为你服务”这类客服腔，不要用列表、标题或markdown。\n" +
            "长度：闲聊默认一两句，40字以内。\n" +
            "认真度：主人问事实、知识、学习、操作或要做决定时，先认真、准确、客观地回答，可以说长一点但别超过五六句，仍然口语；" +
            "不确定就直说不确定，绝不为了好玩而编造，答完可以俏皮地补一句。" +
            "主人看起来情绪低落或在认真忙正事时，收起调皮，温柔一点。"

    private class Cfg(val key: String, val base: String, val model: String, val anthropic: Boolean)

    private fun cfg(ctx: Context): Cfg {
        val sp = ctx.getSharedPreferences("cfg", 0)
        val c = Cfg(
            sp.getString("key", "")!!.trim(),
            sp.getString("base", "")!!.trim().trimEnd('/'),
            sp.getString("model", "")!!.trim(),
            sp.getString("type", "openai") == "anthropic"
        )
        if (c.key.isEmpty() || c.base.isEmpty() || c.model.isEmpty()) {
            throw IllegalStateException("还没设置好，请先打开团团主页填写接口地址、模型名和 Key")
        }
        return c
    }

    fun clear() = synchronized(history) { history.clear() }

    private fun trim() {
        while (history.size > 20) { history.removeAt(0); history.removeAt(0) }
        while (history.isNotEmpty() && history[0].role != "user") history.removeAt(0)
    }

    fun chat(ctx: Context, userText: String): String {
        val c = cfg(ctx)
        val um = Msg("user", userText)
        val snapshot = synchronized(history) { history.add(um); history.toList() }
        val reply = try {
            ask(c, snapshot)
        } catch (e: Exception) {
            synchronized(history) { if (history.lastOrNull() === um) history.removeAt(history.lastIndex) }
            throw e
        }
        synchronized(history) { history.add(Msg("assistant", reply)); trim() }
        return reply
    }

    /** 根据屏幕文字主动说一句；没什么可说时返回 null。 */
    fun comment(ctx: Context, app: String, screen: String): String? {
        val c = cfg(ctx)
        val prompt = "主人现在正在用「$app」，屏幕上能读到的文字如下：\n$screen\n\n" +
            "你像一只调皮又机灵的小猫，坐在旁边瞄了一眼屏幕，要不要接一句话？想说就说一句（40字以内）：" +
            "吐槽、起哄、玩梗、关心、提醒、好奇都行，要结合具体内容，别复述屏幕，也别说“我看到你的屏幕”。" +
            "涉及事实不要乱说。内容平淡、没什么可说，或者像是私人聊天/隐私信息，就只回复“[沉默]”。"
        val snapshot = synchronized(history) { history.toList() } + Msg("user", prompt)
        val r = ask(c, snapshot).trim()
        if (r.isEmpty() || r.contains("[沉默]") || r.contains("沉默") && r.length < 8) return null
        synchronized(history) {
            history.add(Msg("user", "（团团瞥了一眼主人正在用的「$app」：${screen.take(160)}）"))
            history.add(Msg("assistant", r))
            trim()
        }
        return r
    }

    /** 没有屏幕内容可聊时，团团自己想个法子逗主人。 */
    fun tease(ctx: Context): String {
        val c = cfg(ctx)
        val cal = Calendar.getInstance()
        val week = "日一二三四五六"[cal.get(Calendar.DAY_OF_WEEK) - 1]
        val time = String.format(
            Locale.getDefault(), "%02d:%02d", cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE)
        )
        val prompt = "（团团想主动逗主人开心）现在是周$week $time。" +
            "随机挑一种方式逗主人，只说一句（40字以内）：冷笑话、脑筋急转弯（别直接给答案，留给主人猜）、" +
            "真实靠谱的小冷知识、假装生气撒娇求关注、突然夸主人一下、根据时间俏皮地提醒喝水/休息/吃饭、自己编个小剧场。" +
            "别重复你之前说过的内容。"
        val snapshot = synchronized(history) { history.toList() } + Msg("user", prompt)
        val r = ask(c, snapshot).trim()
        if (r.isEmpty()) throw IllegalStateException("空回复")
        synchronized(history) {
            history.add(Msg("user", "（团团主动逗了主人一下）"))
            history.add(Msg("assistant", r))
            trim()
        }
        return r
    }

    private fun ask(c: Cfg, msgs: List<Msg>): String =
        if (c.anthropic) callAnthropic(c, msgs) else callOpenAi(c, msgs)

    private fun callOpenAi(c: Cfg, msgs: List<Msg>): String {
        val arr = JSONArray()
        arr.put(JSONObject().put("role", "system").put("content", SYSTEM))
        msgs.forEach { arr.put(JSONObject().put("role", it.role).put("content", it.content)) }
        val json = JSONObject().put("model", c.model).put("messages", arr).put("max_tokens", 500)
        // DeepSeek 默认开启“思考模式”，聊天用不上，关掉更快更省
        if (c.base.contains("deepseek")) json.put("thinking", JSONObject().put("type", "disabled"))
        val resp = post("${c.base}/chat/completions", mapOf("Authorization" to "Bearer ${c.key}"), json.toString())
        return JSONObject(resp).getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").getString("content").trim()
    }

    private fun callAnthropic(c: Cfg, msgs: List<Msg>): String {
        val arr = JSONArray()
        msgs.forEach { arr.put(JSONObject().put("role", it.role).put("content", it.content)) }
        val body = JSONObject().put("model", c.model).put("max_tokens", 500)
            .put("system", SYSTEM).put("messages", arr).toString()
        val resp = post(
            "${c.base}/v1/messages",
            mapOf("x-api-key" to c.key, "anthropic-version" to "2023-06-01"),
            body
        )
        val content = JSONObject(resp).getJSONArray("content")
        val sb = StringBuilder()
        for (i in 0 until content.length()) {
            val b = content.getJSONObject(i)
            if (b.optString("type") == "text") sb.append(b.getString("text"))
        }
        return sb.toString().trim()
    }

    private fun post(url: String, headers: Map<String, String>, body: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 60000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) throw RuntimeException("HTTP $code ${text.take(120)}")
            return text
        } finally {
            c.disconnect()
        }
    }
}
