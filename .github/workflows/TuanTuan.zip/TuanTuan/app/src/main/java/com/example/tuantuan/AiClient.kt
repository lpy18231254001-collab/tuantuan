package com.example.tuantuan

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object AiClient {

    data class Msg(val role: String, val content: String)

    val history = mutableListOf<Msg>()

    private const val SYSTEM =
        "你是桌面宠物团团，一只圆滚滚、有点爱撒娇的小猫，住在主人的手机屏幕上。" +
            "回答要简短口语化，尽量不超过30个字，不要使用markdown或表情符号以外的特殊格式。" +
            "遇到需要认真回答的问题，要给出准确的答案，不要为了可爱而乱说。"

    fun clear() = synchronized(history) { history.clear() }

    fun chat(ctx: Context, userText: String): String {
        val sp = ctx.getSharedPreferences("cfg", 0)
        val key = sp.getString("key", "")!!.trim()
        val base = sp.getString("base", "")!!.trim().trimEnd('/')
        val model = sp.getString("model", "")!!.trim()
        val anthropic = sp.getString("type", "openai") == "anthropic"
        if (key.isEmpty() || base.isEmpty() || model.isEmpty()) {
            throw IllegalStateException("还没设置好，请先回团团主页填写接口地址、模型名和 API Key")
        }

        val um = Msg("user", userText)
        val snapshot: List<Msg>
        synchronized(history) {
            history.add(um)
            snapshot = history.toList()
        }

        val reply = try {
            if (anthropic) callAnthropic(base, key, model, snapshot)
            else callOpenAi(base, key, model, snapshot)
        } catch (e: Exception) {
            synchronized(history) {
                if (history.lastOrNull() === um) history.removeAt(history.lastIndex)
            }
            throw e
        }

        synchronized(history) {
            history.add(Msg("assistant", reply))
            while (history.size > 20) {
                history.removeAt(0)
                history.removeAt(0)
            }
        }
        return reply
    }

    private fun callOpenAi(base: String, key: String, model: String, msgs: List<Msg>): String {
        val arr = JSONArray()
        arr.put(JSONObject().put("role", "system").put("content", SYSTEM))
        msgs.forEach { arr.put(JSONObject().put("role", it.role).put("content", it.content)) }
        val body = JSONObject()
            .put("model", model)
            .put("messages", arr)
            .put("max_tokens", 400)
            .toString()
        val resp = post("$base/chat/completions", mapOf("Authorization" to "Bearer $key"), body)
        return JSONObject(resp).getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").getString("content").trim()
    }

    private fun callAnthropic(base: String, key: String, model: String, msgs: List<Msg>): String {
        val arr = JSONArray()
        msgs.forEach { arr.put(JSONObject().put("role", it.role).put("content", it.content)) }
        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 400)
            .put("system", SYSTEM)
            .put("messages", arr)
            .toString()
        val resp = post(
            "$base/v1/messages",
            mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"),
            body
        )
        val content = JSONObject(resp).getJSONArray("content")
        val sb = StringBuilder()
        for (i in 0 until content.length()) {
            val b = content.getJSONObject(i)
            if (b.optString("type") == "text") sb.append(b.getString("text"))
        }
        return sb.toString().trim()
    }

    private fun post(url: String, headers: Map<String, String>, body: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 60000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) throw RuntimeException("HTTP $code：${text.take(200)}")
            return text
        } finally {
            c.disconnect()
        }
    }
}
